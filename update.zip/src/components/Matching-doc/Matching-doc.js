import  {multiStepContext } from '../../StepContext';
import { useContext, useState, useRef, useEffect } from 'react'
import { TextField} from '@mui/material';
import { Button } from 'react-bootstrap';

import Grid from '@mui/material/Grid';
import { Viewer } from '@react-pdf-viewer/core'; // install this library
// Plugins
import { defaultLayoutPlugin } from '@react-pdf-viewer/default-layout'; // install this library
// Import the styles
import '@react-pdf-viewer/core/lib/styles/index.css';
import '@react-pdf-viewer/default-layout/lib/styles/index.css';
// Worker
import  LinearProgress from  '@mui/material/LinearProgress'

import { Worker } from '@react-pdf-viewer/core'; // install this library
import WebViewer from '@pdftron/webviewer';
import Retrain from '../retrain/Retrain';
const MatchingDoc=()=>{
const {setStep,userData,setUserData,files, setFiles,view,setView,filePath,filePath1,setFilePath1,filePath2,setFilePath2,numTitre,setNumTitre}=useContext(multiStepContext)
const defaultLayoutPluginInstance = defaultLayoutPlugin();
const viewer = useRef(null);
const viewer2 = useRef(null);



  
  
//end
// if using a class, equivalent of componentDidMount
  
   

useEffect(() => {

    WebViewer(

      {

        path: 'lib',

        initialDoc:filePath1                                                                              

      },

      viewer.current,

    ).then((instance) => {

      const { documentViewer, annotationManager, Annotations } = instance.Core;



      documentViewer.addEventListener('documentLoaded', () => {

        const rectangleAnnot = new Annotations.RectangleAnnotation({

          PageNumber: 1,

          // values are in page coordinates with (0, 0) in the top left

          X: 100,

          Y: 150,

          Width: 200,

          Height: 50,

          Author: annotationManager.getCurrentUser()

        });



        annotationManager.addAnnotation(rectangleAnnot);

        // need to draw the annotation otherwise it won't show up until the page is refreshed

        annotationManager.redrawAnnotation(rectangleAnnot);

      });

    });

  }, [filePath1]);
  useEffect(() => {

    WebViewer(

      {

        path: 'lib',

        initialDoc:filePath2                                                                             

      },

      viewer2.current,

    ).then((instance) => {

      const { documentViewer, annotationManager, Annotations } = instance.Core;



      documentViewer.addEventListener('documentLoaded', () => {

        const rectangleAnnot = new Annotations.RectangleAnnotation({

          PageNumber: 1,

          // values are in page coordinates with (0, 0) in the top left

          X: 100,

          Y: 150,

          Width: 200,

          Height: 50,

          Author: annotationManager.getCurrentUser()

        });



        annotationManager.addAnnotation(rectangleAnnot);

        // need to draw the annotation otherwise it won't show up until the page is refreshed

        annotationManager.redrawAnnotation(rectangleAnnot);

      });

    });

  }, [filePath2]);
const returnFile=()=>{
    setStep(1)
    setFiles(...files)
}

    return(
      <div className='App'>
 
        <div className='pdf-center'>
         
         

                    {filePath1.length>0 && filePath2.length>0 ?(
                <>  <Grid container rowSpacing={3}  columnSpacing={2}><Grid item md={2}>
                <Retrain/>
  
              </Grid>
                                    <Grid item md={5}>

                <div className="webviewer" ref={viewer}></div> 
                </Grid>
                <Grid item md={5}>

                <div className="webviewer" ref={viewer2}></div> 
               </Grid>
               <div>
               <Button onClick={()=>setStep(1)} >&laquo;Précedent</Button> &nbsp;&nbsp;&nbsp;
              <Button onClick={()=>setStep(3) }>suivant &raquo;</Button></div>
              </Grid>

                </>):(<><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><h5>ATTENDZ QUELQUES MINUTES CE PROCESSUS PRENDRE DU TEMPS ... {numTitre} </h5><br></br><LinearProgress className='progress' /><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><Button className='btn' onClick={()=>setStep(1)} >&laquo;Précedent</Button> &nbsp;&nbsp;&nbsp;
              <Button className='btn' onClick={()=>setStep(3) }>suivant &raquo;</Button></>)}

           

                            
       
        <br></br>
       
      
        
       
        </div>

        </div>
    )
}
export default MatchingDoc
