import  {multiStepContext } from '../../StepContext';
import { useContext, useState } from 'react'
import axios from 'axios';
import { Box } from '@material-ui/core';
import './style.css';
import { Button } from 'react-md';
import { TextField} from '@mui/material';
import { color } from '@mui/system';
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css"  ;


const Retrain=()=>{
  const {setStep,userData,setUserData,files, setFiles,view,setView,filePath,filePath1,setFilePath1,filePath2,setFilePath2}=useContext(multiStepContext)
  const[sentence1,setSentence1]=useState('')
  const[sentence2,setSentence2]=useState('')
  const[erreursubmit,setErreursubmit]=useState('')
  const [num, setNum]= useState();
  const config = {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }
  const handleSentence1=(event)=>{
      setSentence1(event.target.value)
    }
    const handleSentence2=(event)=>{
      setSentence2(event.target.value)
    }
    const evaluer=()=>{
     
      if (sentence1.length>1 && sentence2.length>1){
          setErreursubmit('')
         
          const formData = new URLSearchParams();
         formData.append('sentence1', sentence1.toString());
         formData.append('sentence2', sentence2.toString());
         formData.append('num',num)
          console.log(formData)
          console.log(sentence1.toString())
          console.log(sentence2.toString())
          console.log(num)
             
              axios.post('http://localhost:5000/feedback',formData,config).then(res=>{
                console.log(res)
                setSentence1('')
                setSentence2('')
                setNum(0)
         }).catch(err=>{
              console.log(err);

           })
    
  
 }
 else{
     setErreursubmit('remplir les inputs corretement !!!')}

 }


 
 
  let incNum =()=>{
    if(num<1)
    {
    setNum(Number(num)+0.01);
    }
  };
  let decNum = () => {
     if(num>0)
     {
      setNum(num - 0.01);
     }
  }
  let handleChange = (e)=>{
    setNum(e.target.value);
   }   

      

    
  const style = {
          "& .MuiOutlinedInput-root": {
            "&.Mui-focused fieldset": {
              borderColor: "black",
              color:"black"
            }
          }
        }   
      
  return(
      <div>

      <div className='retrain'>
          <div className='essai'></div>
          <Box><TextField sx={style} label="Sentence1"   name="sentence1" className='input' value={sentence1} onChange={handleSentence1}/> 
          </Box>
          <br></br>
         
          <Box><TextField sx={style} label="Sentence2"  name="sentence2" className='input' value={sentence2} onChange={handleSentence2}/>
          </Box>
          <br></br>
         <br></br>
          <>
  
  <div class="input-group">
<div class="input-group-prepend">
  <button class="btn btn-outline-primary" type="button" onClick={decNum}>-</button>
</div>
<input  placeholder='Similarité %' name='num'  type="number" min="0" max="1" step="0.1" class="form-control" value={num} onChange={handleChange}/>
<div class="input-group-prepend">
  <button class="btn btn-outline-primary" type="button" onClick={incNum}>+</button>
</div>
 </div> 

 </>

          
         
          <br></br>
          <Button onClick={evaluer} className="button" role="button"  >Evaluer</Button>
          <br></br>
          {erreursubmit&&<div className='error-msg'>{erreursubmit}</div>}

      </div>
      
      </div>

  )
}

export default Retrain
