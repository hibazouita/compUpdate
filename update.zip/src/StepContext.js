import React,{useState} from "react";
import App from "./App";
export const multiStepContext = React.createContext();
const StepContext =()=>{
    const [currentStep,setStep]=useState(1)
    const [userData,setUserData]=useState([])
    const [finalData,setFinalData]=useState([])
    const [files, setFiles]=useState([])
    const [view, setView]=useState([])
    const[sommaire,setSommaire]=useState("")
    const [pdfFileError, setPdfFileError]=useState('');
    const [filePath,setFilePath]=useState({})
    const[filePath1,setFilePath1]=useState("")
    const[filePath2,setFilePath2]=useState("")
    const[numTitre,setNumTitre]=useState(0)
    return (
        <div>
            <multiStepContext.Provider value={{currentStep,setStep,userData,setUserData,finalData,setFinalData,files,setFiles,view, setView,sommaire,setSommaire,pdfFileError, setPdfFileError,filePath,setFilePath,filePath1,setFilePath1,filePath2,setFilePath2,numTitre,setNumTitre}}>
                <App/>
            </multiStepContext.Provider>
        </div>
    )
}
export default StepContext;